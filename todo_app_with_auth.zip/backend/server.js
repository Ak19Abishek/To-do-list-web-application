const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/todo_auth_app');

const userSchema = new mongoose.Schema({
  username: String,
  password: String,
});

const todoSchema = new mongoose.Schema({
  userId: String,
  text: String,
  completed: Boolean,
});

const User = mongoose.model('User', userSchema);
const Todo = mongoose.model('Todo', todoSchema);

const authenticate = async (req, res, next) => {
  const token = req.headers.authorization;
  if (!token) return res.status(403).json({ error: 'No token provided' });
  try {
    const decoded = jwt.verify(token, 'secret');
    req.user = decoded;
    next();
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
};

app.post('/register', async (req, res) => {
  const hashedPassword = await bcrypt.hash(req.body.password, 10);
  const user = new User({ username: req.body.username, password: hashedPassword });
  await user.save();
  res.sendStatus(201);
});

app.post('/login', async (req, res) => {
  const user = await User.findOne({ username: req.body.username });
  if (!user || !(await bcrypt.compare(req.body.password, user.password))) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  const token = jwt.sign({ id: user._id }, 'secret');
  res.json({ token });
});

app.get('/todos', authenticate, async (req, res) => {
  const todos = await Todo.find({ userId: req.user.id });
  res.json(todos);
});

app.post('/todos', authenticate, async (req, res) => {
  const todo = new Todo({ userId: req.user.id, text: req.body.text, completed: false });
  await todo.save();
  res.json(todo);
});

app.put('/todos/:id', authenticate, async (req, res) => {
  const todo = await Todo.findOneAndUpdate(
    { _id: req.params.id, userId: req.user.id },
    { completed: req.body.completed },
    { new: true }
  );
  res.json(todo);
});

app.delete('/todos/:id', authenticate, async (req, res) => {
  await Todo.findOneAndDelete({ _id: req.params.id, userId: req.user.id });
  res.sendStatus(204);
});

app.listen(5000, () => console.log('Server running on http://localhost:5000'));
