import { useEffect, useState } from 'react';
import axios from 'axios';

const API = 'http://localhost:5000';

function App() {
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [todos, setTodos] = useState([]);
  const [text, setText] = useState('');
  const [auth, setAuth] = useState({ username: '', password: '' });
  const [loggedIn, setLoggedIn] = useState(!!token);

  useEffect(() => {
    if (token) fetchTodos();
  }, [token]);

  const fetchTodos = async () => {
    const res = await axios.get(`${API}/todos`, { headers: { Authorization: token } });
    setTodos(res.data);
  };

  const addTodo = async () => {
    const res = await axios.post(`${API}/todos`, { text }, { headers: { Authorization: token } });
    setTodos([...todos, res.data]);
    setText('');
  };

  const toggleTodo = async (id, completed) => {
    const res = await axios.put(`${API}/todos/${id}`, { completed }, { headers: { Authorization: token } });
    setTodos(todos.map(t => (t._id === id ? res.data : t)));
  };

  const deleteTodo = async id => {
    await axios.delete(`${API}/todos/${id}`, { headers: { Authorization: token } });
    setTodos(todos.filter(t => t._id !== id));
  };

  const handleLogin = async () => {
    const res = await axios.post(`${API}/login`, auth);
    localStorage.setItem('token', res.data.token);
    setToken(res.data.token);
    setLoggedIn(true);
  };

  const handleRegister = async () => {
    await axios.post(`${API}/register`, auth);
    handleLogin();
  };

  const logout = () => {
    localStorage.removeItem('token');
    setToken(null);
    setLoggedIn(false);
    setTodos([]);
  };

  if (!loggedIn) {
    return (
      <div className="p-4 max-w-md mx-auto">
        <h1 className="text-2xl mb-4">Login / Register</h1>
        <input className="border p-2 w-full mb-2" placeholder="Username" value={auth.username} onChange={e => setAuth({ ...auth, username: e.target.value })} />
        <input className="border p-2 w-full mb-2" type="password" placeholder="Password" value={auth.password} onChange={e => setAuth({ ...auth, password: e.target.value })} />
        <div className="flex gap-2">
          <button className="bg-blue-500 text-white px-4 py-2" onClick={handleLogin}>Login</button>
          <button className="bg-green-500 text-white px-4 py-2" onClick={handleRegister}>Register</button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 max-w-md mx-auto">
      <h1 className="text-2xl mb-4">My To-Do List</h1>
      <div className="flex gap-2 mb-4">
        <input className="border p-2 flex-1" value={text} onChange={e => setText(e.target.value)} placeholder="Add task..." />
        <button className="bg-blue-500 text-white px-4" onClick={addTodo}>Add</button>
        <button className="bg-red-500 text-white px-4" onClick={logout}>Logout</button>
      </div>
      <ul>
        {todos.map(todo => (
          <li key={todo._id} className="flex justify-between items-center border-b py-2">
            <span className={todo.completed ? 'line-through' : ''}>{todo.text}</span>
            <div className="flex gap-2">
              <button className="bg-yellow-500 text-white px-2" onClick={() => toggleTodo(todo._id, !todo.completed)}>
                {todo.completed ? 'Undo' : 'Done'}
              </button>
              <button className="bg-red-600 text-white px-2" onClick={() => deleteTodo(todo._id)}>Delete</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
